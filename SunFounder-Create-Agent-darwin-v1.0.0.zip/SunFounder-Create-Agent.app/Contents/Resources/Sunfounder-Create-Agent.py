import sys
from agent import Agent
import threading
import asyncio
import time

__VERSION__ = "v1.0.0-alpha-7"

if sys.platform == 'darwin':
    from systray_darwin import SysTrayIcon
elif sys.platform == 'win32':
    from systray_win32 import SysTrayIcon

class SunFounder_Create_Agent():

    APP_NAME = "SunFounder Create Agent"
    ICON = 'sca.ico'
    ICON_WHITE = 'sca-white.png'

    def __init__(self):
        self.menu_options = ['Agent %s' % __VERSION__]
        self.agent = Agent(debug=False)
        self.agent_task = asyncio.ensure_future(self.agent.tasks)
        self.loop = asyncio.get_event_loop()
        self.agent_thread = threading.Thread(target=self.run_agent, name="Agent")
        self.sti = SysTrayIcon(icon=self.ICON, icon_white=self.ICON_WHITE, name=self.APP_NAME, menu=self.menu_options, quit_button=self.bye)

    def run_agent(self):
        print("Server starts at: 127.0.0.1:9588")
        self.loop.run_forever()

    def bye(self, sysTrayIcon):
        self.agent.close()
        self.agent_task.cancel()
        self.loop.stop()
        time.sleep(1)
        self.loop.close()
        self.agent_thread.join()
        # quit()

    def run_menu(self):
        self.sti.run()

    def startup_message(self):
        # Notification("Note", "SunFounder Create Agent running in the background.", auto_destory=10)
        pass

    def run(self):
        self.sti.notification("Note", "SunFounder Create Agent running in the background.")
        self.agent_thread.start()
        self.run_menu()

if __name__ == '__main__':
    import pid
    sca = SunFounder_Create_Agent()
    try:
        with pid.PidFile():
            sca.run()
    except KeyboardInterrupt:
        pass
    except RuntimeError:
        pass
    except pid.base.PidFileAlreadyLockedError:
        print("SunFounder Create Agent is already running.")
        sca.sti.notification("Error", "SunFounder Create Agent is already running.",)

# from instance_manager import ProgramInstanceManager, OtherInstanceError
# if __name__ == '__main__':
#     sca = SunFounder_Create_Agent()
#     pim = None
#     try:
#         pim = ProgramInstanceManager()
#         sca.run()
#     except KeyboardInterrupt:
#         pass
#     except RuntimeError:
#         pass
#     except OtherInstanceError:
#         print("SunFounder Create Agent is already running.")
#         sca.sti.notification("Error", "SunFounder Create Agent is already running.",)
#     finally:
#         if pim:
#             pim.shutdown()
